loadstring(game:HttpGet("https://pastebin.com/raw/8V3QXYgr"))()
